#!/bin/bash
asdoc -doc-sources ../src  -main-title "HYPE" -footer "Copyright 2011 Branden Hall and Joshua Davis" -target-player 10 -output ../doc -window-title "HYPE API"

